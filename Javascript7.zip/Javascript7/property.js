const car = {
  brand: "Toyota",
  model: "Corolla",
  year: 2022
};
