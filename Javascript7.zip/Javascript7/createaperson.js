function createPerson(name, age) {
  return {
    name: name,
    age: age
  };
}

console.log(createPerson("Arshu", 20));

