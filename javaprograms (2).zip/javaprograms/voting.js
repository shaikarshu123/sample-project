console.log("person age eligibility")
let age=10
if(age < 18){
    console.log("you cannot vote")
}else{
    console.log("you can vote")
}