function trafficSignal(lightColor) {
    switch(lightColor.toLowerCase()) {
        case "red": return "Stop!";
        case "yellow": return "Get ready!";
        case "green": return "Go!";
        default: return "Invalid signal";
    }
}

console.log(trafficSignal("Green")); // Output: Go!