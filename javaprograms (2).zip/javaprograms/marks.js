let marks=85;

if(marks >=80){
    console.log("grade A");
}else if(marks >=60){
    console.log("grade B ");
}else{
    console.log("grade C")
}