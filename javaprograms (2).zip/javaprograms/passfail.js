let marks=40;

if(marks > 33){
    console.log("pass");
}else{
    console.log("fail")
}