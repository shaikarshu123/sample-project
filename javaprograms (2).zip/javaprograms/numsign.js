console.log("checking a number is positive,negative or zero")
let n=100
if (n>0){
    console.log("your number is positive")
}
else if(n<0){
    console.log("your number is negative")
}
else{
    console.log("your number is zero")
}