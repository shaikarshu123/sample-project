let colors=["red","green","blue","yellow","black"];
for(let i=0;i<colors.length;i++){
    console.log(colors[i]);
}