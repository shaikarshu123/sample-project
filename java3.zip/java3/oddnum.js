for(let i=1;i<=10;i++){
    if(i>7){
        break;
    }
    if(i%2!==0){
        console.log(i);
    }
}