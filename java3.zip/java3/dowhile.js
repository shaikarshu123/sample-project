let i=10;
do{
    console.log("this message is printed at least once.");
}while(i<5);