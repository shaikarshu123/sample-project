console.log("to print 1 to 5 numbers")
for(i=1;i<6;i++){
    console.log(i)
}