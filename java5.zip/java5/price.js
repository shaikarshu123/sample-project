const prices = [10, 25, 99];
const tagged = prices.map(price => `$${price}`);
console.log(tagged);
