const words = ["mahaboobbasha", "mahaboobi", "farru", "arshu", "isha"];
const longWords = words.filter(word => word.length > 1);
console.log(longWords); 
