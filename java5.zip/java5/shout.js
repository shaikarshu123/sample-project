const words = ["hello", "world", "welcome to world"];
const shouted = words.map(word => word.toUpperCase());
console.log(shouted);
