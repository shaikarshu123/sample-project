function addFruit(fruits, newFruit) {
  fruits.push(newFruit);
  return fruits;
}

console.log(addFruit(["apple", "banana"], "mango"));

