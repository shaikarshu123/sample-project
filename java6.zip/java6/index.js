function findIndex(words, target) {
  return words.indexOf(target);
}

console.log(findIndex(["cat", "dog", "bird"], "dog"));
