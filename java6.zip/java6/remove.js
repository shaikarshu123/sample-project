function removeFirst(fruits) {
  fruits.shift();
  return fruits;
}

console.log(removeFirst(["apple", "banana", "mango"]));