function checkItem(items, target) {
  return items.includes(target);
}

console.log(checkItem(["apple", "banana", "mango"], "banana"));


console.log(checkItem(["apple", "banana", "mango"], "grape"));

