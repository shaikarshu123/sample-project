function isEven(number) {
  if (number % 2 === 0) {
    return `${number} is even.`;
  } else {
    return `${number} is odd.`;
  }
}


console.log(isEven(10)); 


console.log(isEven(7));  

