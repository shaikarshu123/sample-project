function welcome(name) {
  return `Hello, ${name}! Welcome aboard 🎉`;
}


console.log(welcome("Arshu")); 

