function isFreezing(tempCelsius) {
  if (tempCelsius <= 0) {
    return `Yes, ${tempCelsius}°C is at or below freezing.`;
  } else {
    return `No, ${tempCelsius}°C is above freezing.`;
  }
}


console.log(isFreezing(-5));  


console.log(isFreezing(10));  
