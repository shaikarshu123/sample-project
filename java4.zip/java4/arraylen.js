function arrayLengthFinder(arr) {
  return arr.length;
}


console.log(arrayLengthFinder([1, 2, 3, 4, 5])); 


console.log(arrayLengthFinder(["apple", "banana", "cherry"])); 

